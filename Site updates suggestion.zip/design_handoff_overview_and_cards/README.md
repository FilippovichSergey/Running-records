# Handoff: Overview page + Race/PB card redesign

## About these files
The referenced designs are **HTML/React mockups** built as prototypes (Design Components), not production code. Target codebase is the real site at `d:\IT\Running_records\` — a **static HTML + vanilla JS** app (`index.html`, `data/data.js`, `data/activities.js`, no framework, no build step). Implement everything below as plain HTML/CSS/JS additions to that existing file, following its existing patterns (inline `<style>` block, vanilla DOM functions like `renderActChart`, `initActivitiesControls`, the `page-*` div-per-tab structure, `t()`/translation object, `--accent` etc. CSS custom properties). Do not introduce React, JSX, or a build step.

## Fidelity
**High-fidelity.** Colors, type, spacing, and copy below are final — recreate pixel-for-pixel using the site's existing CSS variables (`--accent #e8521b`, `--bg`, `--card`, `--border`, `--muted`, `--header`, `--positive`/`--positive-bg`, dark-theme overrides) and the system font stack already in use (`-apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, sans-serif`).

## Scope
1. New **Overview** tab — becomes the default/first tab, before All Runs.
2. Reworked **race card** on the All Runs tab — photo strip + overlapping medal.
3. Reworked **Personal Best card** — built-in progression bar chart.
4. Nav bar gains a 4th tab label "Overview" (site already has All Runs / Personal Bests / Activities).

Everything below is bilingual (EN / BE) — add strings to the site's existing translation object; example values given in both.

---

## 1. Overview tab

### Layout (top to bottom)
1. **Full-bleed photo hero**, `480px` tall, `background:#1a1a1a`, a real race photo (`object-fit:cover`, `object-position:center 42%`) with a dark gradient overlay for text legibility: `linear-gradient(180deg, rgba(20,18,16,.4) 0%, rgba(20,18,16,0) 30%, rgba(20,18,16,.55) 70%, rgba(20,18,16,.92) 100%)`. Content is inset to a `940px` centered column.
   - Top-left, `40px` from left/top: eyebrow label, `12px/700/uppercase/letter-spacing:2px`, `color:rgba(255,255,255,.85)` — "Since 2022 · Georgia" / "З 2022 · Грузія".
   - Lower area (`bottom:128px`): headline, `54px/900/letter-spacing:-2px/line-height:1`, white, max-width `680px`, with the distance number in `--accent`: **"353 km raced across 17 finish lines."** / **"353 км на 17 фінішах."**
   - Bottom stat strip (`bottom:38px`, flex row, `gap:44px`, align `flex-end`): 3 stat blocks, each a big white numeral (`34px/900/letter-spacing:-1px`) + small muted unit + tiny uppercase label below (`9px/700/letter-spacing:1px/color:rgba(255,255,255,.6)`):
     - `7,821 m` — Climbed / Набор вышыні
     - `100.5 km` — Longest race / Самая доўгая
     - `19:14` — Fastest 5K / Хуткі 5К
   - Far right of that row: pill button, `--accent` bg, white text, `20px` radius, `8px 17px` padding, `11px/700/uppercase` — "Explore the log →" / "Адкрыць журнал →" — clicking navigates to All Runs tab.

2. **Race memories** section, `940px` centered column, `padding:34px 40px 20px`.
   - Header row: title "Race memories" / "Успаміны з гонак" (`22px/800/letter-spacing:-.5px`) + right-aligned meta "142 photos · 11 medals" / "142 фота · 11 медалёў" (`11px/700/uppercase/muted`).
   - Photo grid: CSS grid `grid-template-columns: 2fr 1fr 1fr; grid-template-rows: 140px 140px; gap:10px`. 5 cells:
     - Cell 1 spans both rows (`grid-row:span 2`) — largest photo, `14px` radius, with a caption overlay bottom-left (white, `14px/800`, text-shadow `0 1px 5px rgba(0,0,0,.6)`) e.g. "Lisi Trail · 44 km".
     - Cells 2–4: single photos, `14px` radius, one with a similar caption overlay.
     - Cell 5: a "+N photos" tile — `background:var(--header)` (dark), centered white text, big number `15px/800` + small "photos" label muted below.
   - Every photo cell is clickable → opens the existing lightbox component (reuse it) starting at that photo.

3. **Latest race** strip, same `940px` column, `padding:14px 40px 56px`.
   - Small uppercase label "Latest race" / "Апошняя гонка" above a single card.
   - Card: `var(--card)` background, `18px` radius, standard card shadow, flex row, `gap:20px`, `padding:18px 24px`:
     - 60×60 round medal photo, `2px` border `var(--border)`.
     - Meta line (date + location, uppercase muted) + race name (`20px/800/letter-spacing:-.4px`) stacked.
     - A green "NEW 5K PB" / "НОВЫ РЭКОРД 5К" pill (`color:var(--positive)`, `background:var(--positive-bg)`, `20px` radius, `5px 12px`).
     - Right-aligned: big accent time numeral (`32px/900/letter-spacing:-1.4px/color:var(--accent)`) + small uppercase sub-label below it (e.g. "5.0 km · 3:51 /km").

### Data used (real numbers — hardcode as constants, matching existing data-driven stats elsewhere in the site)
353 km raced · 17 races finished · 7,821 m climbed · 5 seasons · fastest 5K 19:14 · longest race 100.5 km · latest race: Poti Marathon 2026, 31 May 2026, 5.0 km, 3:51/km pace, new 5K PB.

### Nav change
Add "Overview" / "Агляд" as the **first** nav pill (before "All Runs"), active-state styling matches existing pills (`--accent` bg + white text when active). Overview becomes the default tab on load.

---

## 2. Race card redesign (All Runs tab)

Replace the current race card markup/render function with this structure (keep all existing filter/search/data logic — only the card's visual template changes):

- **Photo strip header**: CSS grid, `grid-template-columns: 2fr 1fr 1fr`, 3 images, `170px` tall, `gap:2px`, rounds the card's top corners (`18px 18px 0 0`), `overflow:hidden`. Use the run's existing photo array (first 3 photos, or repeat the medal photo if fewer than 3 exist). Clicking the strip opens the lightbox with all of that run's photos.
- **Medal overlap**: if the run has a medal photo, position it `absolute`, `right:20px`, `top:-42px` (overlapping up from the card body into the photo strip), `68×68px`, `border-radius:50%`, `3px solid var(--card)` border, drop shadow `0 2px 10px rgba(0,0,0,.25)`.
- **Body** (`padding:18px 24px 4px`): uppercase meta line (date · location) → row with race name (`22px/800/letter-spacing:-.5px`, max-width `320px`) on the left and the big distance numeral (`34px/900/letter-spacing:-1.5px/color:var(--accent)` + small " km" unit) on the right → row of type-tag pills below (existing emoji + tag pill component, unchanged).
- **Stat rail**: 4-column grid (Pace / Climb-or-dash / Avg HR / Time), `1px` gap lines in `var(--border)`, each cell centered text, tiny uppercase label + `16px/800` value — this replaces the current 3-column stat rail; reuses existing stat values, just restyled to 4 columns and rounds the card's bottom corners.
- Drop the old "Photos & details ▾" expand row entirely — photos are now always visible up top, so no expand/collapse is needed for this card type.

---

## 3. Personal Best card redesign

Keep the existing dark cap (distance + time + delta pill + date/location/shoe sub-info) — **unchanged**. Add directly below the existing stat row:

- **Progression chart** block (`padding:18px 24px 8px`, only shown when the PB has ≥2 historical results): tiny uppercase label "Four years, chipping away" / "Чатыры гады прагрэсу" above a flex-row bar chart, `height:100px`, `gap` between bars ~12–14px. Each bar: `flex:1`, max-width `34–36px`, `border-radius:6px 6px 0 0`, height scaled to that year's time (faster = taller, normalize so the fastest/most-recent bar is tallest). Color-code by recency: oldest attempts `#efe9df` (pale), middle attempts `#f6b79c` (mid), the actual PB bar in solid `--accent`, with a small "PB" label floated above it (`11px/800/color:--accent`). Year label below each bar (`9px/700`, muted for non-PB years, `var(--text)`/800 for the PB year).
- Keep the existing "Previous records" history rows list below the chart, unchanged.
- For PB entries with 0–1 history rows (e.g. a brand-new first-time PB), skip the chart entirely — same as today's behavior for those cards.

---

## Design tokens (existing — reuse, do not add new ones)
- Accent: `#e8521b`
- Positive/improvement: text `#1a7a3a` (light) / `#6dba6d` (on dark cap), bg `#e8f8ee` / `rgba(45,106,45,.2)`
- Card radius `18px`, card shadow `0 2px 16px rgba(0,0,0,.07)`, pill radius `20px`, photo/thumb radius `12–14px`
- Type-tag palette: sprint `#7c3aed`, mid `#2563eb`, long `#059669`, marathon `#d97706`, ultra `#dc2626`, trail `#78350f` — each at 10% bg tint / 30% border tint
- Type stack: system UI only, no webfonts
- Numerals: 800–900 weight, negative letter-spacing (`-1px` to `-3px` depending on size); metadata labels: 9–12px/700/uppercase/wide tracking

## Assets
Race/medal photos referenced above (`kazbegi-*.jpg`, `lisi-trail-*.jpg`, `backyard-*.jpg`, `medal-*.jpg`, etc.) already exist in the repo's `data/photos/` — reuse them; no new assets needed.

## Reference files
Full-fidelity mockups for all three Overview directions (Masthead / Photo Hero / Trophy Wall — Photo Hero is the one specified for build), the reworked race card, and the reworked PB card are in this bundle as `overview-and-card-mockups.html` — open in a browser to see exact spacing/typography/colors live.
